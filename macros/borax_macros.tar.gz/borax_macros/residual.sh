
root -l -q -b p2p_truthDiff.C\+\+ >> residual.txt

rm p2p_truthDiff_C*