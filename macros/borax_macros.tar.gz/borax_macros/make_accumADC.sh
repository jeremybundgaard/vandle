#!/bin/bash

time root -l -q -b ~/macros/make_accumADC.C\+\+

rm make_accumADC_*
