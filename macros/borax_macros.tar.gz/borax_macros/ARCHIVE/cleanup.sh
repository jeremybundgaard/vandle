rm *_C.d
rm *_C.so
